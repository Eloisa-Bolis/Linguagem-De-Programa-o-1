/**
 *
 * @author 05908897027
 */
public class conta {
    
    private int numero;
    private String nome;
    private double saldo;
    private double limite;
    
    //2)Criar um método construtor que inicializa cada um
    //dos os atributos com um determinado valor que é
    //passado como parâmetro.
    public conta(int numero, String nome, double saldo, double limite){
        
        this.numero = numero;
        this.nome = nome;
        this.saldo = saldo;
        this.limite = limite;
    }
    
    //3) Crie um método acessor para cada um dos atributos
    public int getnumero(){
        return this.numero;
    }
    public String getnome(){
        return this.nome;
    }   
    public double getsaldo(){
        return this.saldo;
    }    
    public double getlimite(){
        return this.limite;
    }
    
    //4)Crie um método mutante para cada um dos atributos
    public void setnumero(int num){
        this.numero = num;
    }
    public void setnome(String nom){
        this.nome = nom;
    }
    public void setsaldo(double sal){
        this.saldo = sal;
    }
    public void setlimite(double lim){
        this.limite = lim;
    }
    
    //5)Crie um método “sacar” que desconta um valor do saldo da conta se não ultrapassar o limite e outro
    //método “depositar” que acrescenta um valor no saldo da conta. 
    public double sacar(double sacar){
        if(sacar < this.limite+this.saldo){
            this.saldo = (this.saldo - sacar);
        } else {
            System.out.println("ERRO - valor maior que o limite");
        }
        return this.saldo;
    }
    public double depositar(double depositar){
        this.saldo = (this.saldo + depositar);      
        return this.saldo;
    }
    
    public void exibirDados() {
        System.out.println(" ");
        System.out.println("Codigo: " + this.numero);
        System.out.println("Nome: " + this.nome);
        System.out.println("Saldo: " + this.saldo);
        System.out.println("Limite: " + this.limite);
        System.out.println("----------------------------");
    }
}

