/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 05908897027
 */
public class Escola {
    
    public static void main(String[] args) {
       
        Aluno o1 = new Aluno ("001", "Erika", 2009, 4, 10.0, 8.0);
        Aluno o2 = new Aluno ("002", "Eloisa", 2008, 8, 9.5, 8.5);
        Aluno o3 = new Aluno ("003", "Marilia", 2008, 5, 7.0, 8.6);
        Aluno o4 = new Aluno ("004", "Leticia", 2008, 5, 10.0, 6.0);
        Aluno o5 = new Aluno ("005", "Joao Baruffi", 2008, 12, 5.0, 3.0);
        
        o1.exibirDados();
        o2.exibirDados();
        o3.exibirDados();
        o4.exibirDados();
        o5.exibirDados();
        
        
    }
}
