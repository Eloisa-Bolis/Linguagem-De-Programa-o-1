//classe filha (sub classe)     / tem herança
/**
 *
 * @author 05908897027
 */
public class pessoa {

    protected String nome;      //vão ser visiveis para as filhas(sub classes)
    protected String endereco; 
    protected String telefone;
    
    public String getnome(){        //metodos acessores
        return this.nome;
    }    
    public String getendereco(){
        return this.endereco;
    }
    public String gettelefone(){
        return this.telefone;
    }

    public void setNome(String nome) {      //mutantes
        this.nome = nome;
    }
    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
    
    public pessoa(String nome, String endereco, String telefone){
        
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
    }
    
    public void exibirDados() {
        System.out.println(" ");
        System.out.println("Nome: " + this.nome);
        System.out.println("Endereco: " + this.endereco);
        System.out.println("Telefone: " + this.telefone);
        System.out.println("----------------------------");
    }

}
