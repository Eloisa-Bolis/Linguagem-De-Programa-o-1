/**
 *
 * @author 05908897027
 */
public class fornecedor extends pessoa {
    
    protected double valorCredito;
    protected double valorDivida;
    
    public fornecedor(String nome, String endereco, String telefone, double valorCredito, double valorDivida) {
        super(nome, endereco, telefone);
        
        this.valorCredito = valorCredito;
        this.valorDivida = valorDivida;
    }

    public double getValorCredito() {
        return valorCredito;
    }
    public double getValorDivida() {
        return valorDivida;
    }

    public void setValorCredito(double valorCredito) {
        this.valorCredito = valorCredito;
    }
    public void setValorDivida(double valorDivida) {
        this.valorDivida = valorDivida;
    }
       
    public double obterSaldo(){
        double saldo = (this.valorCredito - this.valorDivida);
        return saldo;
    }
    
    public void exibirDadosFor() {
        System.out.println(" ");
        System.out.println("Nome: " + this.nome);
        System.out.println("Endereco: " + this.endereco);
        System.out.println("Telefone: " + this.telefone);
        System.out.println("Credito: " + this.valorCredito);
        System.out.println("Divida: " + this.valorDivida);
    }
}
