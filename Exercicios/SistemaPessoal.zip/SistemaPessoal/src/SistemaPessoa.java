/**
 *
 * @author 05908897027
 */
public class SistemaPessoa {

    public static void main(String[] args) {
        
        pessoa p1 = new pessoa ( "Henrique", "Rua Campos Salles, 14", "2512-4099");
        
        p1.exibirDados(); 
        
        p1.setNome("Erika");  
        p1.setEndereco("Rua tal, 24");  
        p1.setTelefone("2586-2358");  
        
        p1.exibirDados();
        
        fornecedor f1 = new fornecedor ( "Leticia", "Rua Campos Salles, 14", "2512-4099", 5000.00, 1500.00);
        
        f1.exibirDadosFor();
        System.out.println("Saldo: " + f1.obterSaldo());
        System.out.println("----------------------------");
        
        empregado e1 = new empregado ("Marilia", "Rua qualquer, 56", "3707-7659", 3467, 10000.00, 0.5);
        
        e1.exibirDadosEm();
        System.out.println("Salario Total " + e1.calcularSalario());
        System.out.println("----------------------------");
        
    }
    
}
