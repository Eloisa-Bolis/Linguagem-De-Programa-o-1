//super classe
/**
 *
 * @author 05908897027
 */
public class funcionario {
       
    protected String nome;
    protected String cpf;
    protected double salario;

    public funcionario(String nome, String cpf, double salario) {
        this.nome = nome;
        this.cpf = cpf;
        this.salario = salario;
    }
    
    public String getNome() {
        return nome;
    }
    public String getCpf() {
        return cpf;
    }
    public double getSalario() {
        return salario;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }
    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public double getBonificacao() {
        return this.salario * 0.10;
    }
    
    
    public class ControleDeBonificacoes {
    public double totalDeBonificacoes = 0;
    
    public void registra(funcionario funcionario) {
        this.totalDeBonificacoes += funcionario.getBonificacao();
    }
    
    public double getTotalDeBonificacoes() {
        return this.totalDeBonificacoes;
    }

    public void setTotalDeBonificacoes(double totalDeBonificacoes) {
        this.totalDeBonificacoes = totalDeBonificacoes;
    }
    
}

    
    public void exibirDadosFun() {
        System.out.println(" Funcionario:");
        System.out.println("Nome: " + this.nome);
        System.out.println("Cpf: " + this.cpf );
        System.out.println("Salario: " + this.salario);
        System.out.println("Bonificacao: " + this.getBonificacao());
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
    }
}

