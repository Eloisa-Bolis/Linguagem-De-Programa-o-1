//main
/**
 *
 * @author 05908897027
 */
public class empresa {

    public static void main(String[] args) {
        
        funcionario f1 = new funcionario("Jose Antonio", "111111111", 1000.00);
        
        f1.exibirDadosFun();
        
        gerente f2 = new gerente("Pedro Henrique", "222222222", 5000.00, 3573, 5);
        
        f2.exibirDadosGe();

    }
    
}
