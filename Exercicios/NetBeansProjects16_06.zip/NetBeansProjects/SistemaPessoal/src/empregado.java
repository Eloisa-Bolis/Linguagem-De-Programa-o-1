/**
 *
 * @author 05908897027
 */
public class empregado extends pessoa {
    
    protected int codigoSetor;
    protected double salarioBase;
    protected double imposto;
    
    public empregado(String nome, String endereco, String telefone, int codigoSetor, double salarioBase, double imposto) {
        super(nome, endereco, telefone);
        
        this.imposto = imposto;
        this.salarioBase = salarioBase;
        this.codigoSetor = codigoSetor;
    }

    public int getCodigoSetor() {
        return codigoSetor;
    }
    public double getSalarioBase() {
        return salarioBase;
    }
    public double getImposto() {
        return imposto;
    }

    public void setCodigoSetor(int codigoSetor) {
        this.codigoSetor = codigoSetor;
    }
    public void setSalarioBase(double salarioBase) {
        this.salarioBase = salarioBase;
    }
    public void setImposto(double imposto) {
        this.imposto = imposto;
    } 
    
    public double calcularSalario(){
        double valorRetorno = this.salarioBase - (this.salarioBase * this.imposto);
        return valorRetorno;
    }
    
    public void exibirDadosEm() {
        System.out.println(" ");
        System.out.println("Nome: " + this.nome);
        System.out.println("Endereco: " + this.endereco);
        System.out.println("Telefone: " + this.telefone);
        System.out.println("Codigo Setor: " + this.codigoSetor);
        System.out.println("Salario: " + this.salarioBase);
        System.out.println("Imposto: " + this.imposto);
    }
    
}
