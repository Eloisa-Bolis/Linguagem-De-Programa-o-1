/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 05908897027
 */
public class Aluno {
    
    private String codigo;
    private String nome;
    private int anoNascmento;
    private int mesNascimento;
    private double nota_1;
    private double nota_2;
    
    private int anoAtual = 2025;
    private int mesAtual = 03;
    private int idade;
    private int mes;
    
    
    public Aluno(String codigo, String nome, int anoNascmento, int mesNascimento, double nota_1, double nota_2) {
       
        this.codigo = codigo;
        this.nome = nome;
        this.anoNascmento = anoNascmento;
        this.mesNascimento = mesNascimento;
        this.nota_1 = nota_1;
        this.nota_2 = nota_2;
        
        
        
    }
    
    public int ano(){
        this.idade = 2025 - this.anoNascmento;
        if( this.mesNascimento > 3) {
            idade = idade - 1 ;
        }
        return idade;
    }
    
    public int mes(){
        int idade25 = (2025 - this.anoNascmento);
        int meses = (idade25 * 12);
        this.mes = (meses - this.mesNascimento);
        return mes;         
    }
    
    public double calcularMedia() {
        return (this.nota_1 + this.nota_2) / 2;
    }

    public void exibirDados() {
        System.out.println("");
        System.out.println("Codigo: " + this.codigo);
        System.out.println("Nome: " + this.nome);
        System.out.println("Idade: " + this.ano() + " anos (" + this.mes() + " meses de vida)");
        System.out.println("Media das notas: " + this.calcularMedia());
        System.out.println("----------------------------");
    }
   
}
