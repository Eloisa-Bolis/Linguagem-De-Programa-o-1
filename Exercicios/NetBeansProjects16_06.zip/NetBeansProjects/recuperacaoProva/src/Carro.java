/**
 *
 * @author 05908897027
 */
public class Carro extends Veiculo {
    
    public Carro(String modelo){
        super(modelo);
    }
    
    @Override
    public void mover(){
        System.out.println("Estou me movendo");
        System.out.println(" ");
    }
    
}
