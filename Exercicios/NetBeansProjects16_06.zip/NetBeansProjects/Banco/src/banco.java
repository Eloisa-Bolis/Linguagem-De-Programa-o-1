
import java.util.Scanner;

/**
 *
 * @author 05908897027
 */
public class banco {

    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in); 
        
        //Depois de criar a classe, use-a instanciando dois objetos (no primeiro objeto defina um saldo de R$
        //250,00 e um limite de R$ 200,00) desta classe inventando valores para os atributos.  
        conta o1 = new conta (231, "Erika", 250.00, 200.00);
        conta o2 = new conta (672, "Riciery", 2500.00, 3000.00);

        //)Mostre na tela os valores do atributo saldo de cada um dos dois objetos. 
        o1.exibirDados();
        o2.exibirDados();
        
        //Invoque o método sacar do primeiro objeto sacando R$ 500,00 e invoque o método depositar do segundo objeto depositando R$ 1.700,00
        o1.sacar(500.00);
        o2.depositar(1700.00);
        
        //Mostre novamente os valores do atributo saldo de cada um dos objetos
        o1.exibirDados();
        o2.exibirDados();
        
        
        
        System.out.println("Entre com o numero da conta:");
        int num = leitor.nextInt();
        
        System.out.println("Entre com o seu nome:");
        String nome = leitor.next();
        
        System.out.println("Entre com o saldo da conta:");
        double sal = leitor.nextDouble();
        
        System.out.println("Entre com o limite da conta:");
        double lim = leitor.nextDouble();
        
        conta o3 = new conta (num, nome, sal, lim);
        o3.exibirDados();
        
        System.out.println("Quanto voce quer sacar?");
        double sac = leitor.nextDouble();
        o3.sacar(sac);
    }
    
}
