//classe filha
/**
 *
 * @author 05908897027
 */
public class contaPoupanca extends conta{
    
    private double taxaJuros;

    public contaPoupanca(int numero, String nome, double saldo, double taxaJuros) {
        super(numero, nome, saldo, taxaJuros);
        taxaJuros = taxJur;
    }
    
    
    public double gettaxaJuros(){
        return this.taxaJuros;
    }
    public void setTaxaJuros(double taxJur){
        taxaJuros = taxJur;
    }
    
    public void calJuros(){
        saldo *= (1 + taxaJuros);
    }

       
}