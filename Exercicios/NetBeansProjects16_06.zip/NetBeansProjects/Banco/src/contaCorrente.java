// classe filha  
/**
 *
 * @author 05908897027
 */
public class contaCorrente extends conta {
    
    private double limite;

    public contaCorrente(int numero, String nome, double saldo, double limite) {
        //da pra chamar o metodo construtor da classe mae
        super(numero, nome, saldo, limite);
    }
    
    public double getlimite(){
        return this.limite;
    }    
    
    //4)Crie um método mutante para cada um dos atributos
    public void setlimite(double lim){
        this.limite = lim;
    }    
    
}
