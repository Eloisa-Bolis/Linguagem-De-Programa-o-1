/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package supermercado;

public class Item {
    
    String codigo;
    String descricao;
    int quantidade;
    double desconto;
    double preco_unitario;
    double valorDesconto;
    double valorTotal;
    
    
    public Item (String codigo, String descricao, int quantidade, double desconto, double preco_unitario) {
       
        this.codigo = codigo;
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.desconto = desconto;
        this.preco_unitario = preco_unitario;
        
        this.valorDesconto = (quantidade * preco_unitario) * desconto;
        this.valorTotal = (quantidade * preco_unitario) - valorDesconto;
        
    }
    
    /*public double calculo*/
    
}
