/*
Instanciar quatro objetos da classe Item. Aplicar
percentuais de desconto para cada um destes objetos.
Obter os valores totais de cada um desses items. E
imprimir na tela um pequeno recibo com a descricao e o
valor total de cada item e no final o valor total do recibo. 
 */
package supermercado;

/**
 *
 * @author 05908897027
 */
public class SuperMercado {

    public static void main(String[] args) {
        
        double totalTotal = 0;
        
        Item[] produtos = new Item[4];
        
        produtos[0] = new Item("001", "chocolate", 10, 0.5, 12.50);
        produtos[1] = new Item("002", "peixe", 5, 0.5, 30.40);
        produtos[2] = new Item("003", "tela de computador", 2, 0.4, 500.50);
        produtos[3] = new Item("004", "tele transporter", 1, 0.3, 1200000.50);
        
        System.out.println(produtos[0].valorTotal);
        
        
        System.out.println("Cupom Fiscal");
        System.out.println("Codigo:  Descricao:            Quantidade:  Desconto:  Preco:       Valor Total:");
        
        for(int i=0; i<produtos.length; i++){
            
            System.out.printf("%-7s  %-20s  %-11s  %-9s  %-11s  %s  %n",
            produtos[i].codigo, 
            produtos[i].descricao,
            produtos[i].quantidade,
            produtos[i].desconto,
            produtos[i].preco_unitario,
            produtos[i].valorTotal);
            
            totalTotal = totalTotal + produtos[i].valorTotal ;
    
        }
        System.out.println("Total:                                                              " + 
                totalTotal);
        
    }
    
}
