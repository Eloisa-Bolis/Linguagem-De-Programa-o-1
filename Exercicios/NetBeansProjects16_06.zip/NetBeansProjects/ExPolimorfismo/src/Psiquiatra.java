// polimorfismo sobregarga - mesmo nome de metodo com parametros diferentes na mesma classe
/**
 *
 * @author 05908897027
 */
public class Psiquiatra {
    
    public void examinar(Humor h1){
        System.out.println("fale-me, como voce se sente hoje?");
        h1.escreveHumor();
        System.out.println();
    }
    
    public void observar(Triste ot){
        ot.chorar();
        System.out.println("hum interessante, alguma coisa faz voce " + "se sentir triste");
    }
    
    public void observar(Feliz of){
        of.rir();
        System.out.println("hum interessante, alguma coisa faz voce " + "se sentir feliz");
    }
}
