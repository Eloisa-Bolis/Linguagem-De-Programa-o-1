//sub classe
/**
 *
 * @author 05908897027
 */
public class Feliz extends Humor{
    
    protected String getHumor(){    //sob escreve o metodo humor
        return "feliz";
    }
    
    //especializacao
    public void rir(){
        System.out.println("kakakakakakkakakakakakakakakak >:D");
    }
    
}
