/**
 *
 * @author 05908897027
 */
public class Triste extends Humor {
    
    protected String getHumor(){    //sob escreve o metodo humor
        return "triste";
    }
    
    //especializacao
    public void chorar(){
        System.out.println("boooo boooo boooo :( ");
    }
    
}
