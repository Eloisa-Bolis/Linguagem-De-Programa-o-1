//main
//polimorfismo de sob escrita/dinamico

/**
 *
 * @author 05908897027
 */
public class ExPolimorfismo {

    public static void main(String[] args) {
        
        //polimorfismo de sob escrita/dinamico/inclusao
        Humor h1 = new Humor();
        Feliz f1 = new Feliz();  
        Triste t1 = new Triste();
        
        h1.escreveHumor();
        f1.escreveHumor();
        t1.escreveHumor();
        
        
        // polimorfismo sobregarga - mesmo nome de metodo com parametros diferentes na mesma classe
        Psiquiatra p1 = new Psiquiatra();
        
        p1.examinar(h1);
        p1.examinar(f1);
        p1.examinar(t1);
        
        p1.observar(f1);
        p1.observar(t1);
        
    }
    
}
