/**
 *
 * @author 05908897027
 */
public class Homem extends PessoaImc {
    
    public Homem(String nome, String dataNascimento, double peso, double altura) {
        super(nome, dataNascimento, peso, altura);
    }
    
    public String resultIMC(){
        if (calculaImc() < 20.7) {
            return "Abaixo do peso";
        } else {
            if (calculaImc() <= 26.4){
                return "Peso ideal";
            } else {
                return "acima do peso";
            }
        }
    }
    
}
