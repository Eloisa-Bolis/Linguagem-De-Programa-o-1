/**
 *
 * @author 05908897027
 */
import java.util.Scanner;
public class CaculaImc {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        Mulher vetor[] = new Mulher[20];
        
        int cont = 0;
        int num;
        double peso;
        double altura;
        String nome;
        String dataNascimento; 
        
        do{
            System.out.println(" ");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            System.out.println("Escolha a opcao:");
            System.out.println(" ");
            System.out.println("Escolha 1: para cadastrar uma mulher ");
            System.out.println("Escolha 2: para localizar uma mulher ");
            System.out.println("Escolha 3: para imprimir todas as mulheres");
            System.out.println("Escolha 4: para sair ");
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            num = leitor.nextInt();
            
            if (num == 1){
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("digite o nome:");
                nome = leitor.next();
                System.out.println(" ");
                
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("digite a data de nacimento:");
                dataNascimento = leitor.next();
                System.out.println(" ");
                
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("digite o peso:");
                peso = leitor.nextDouble();
                System.out.println(" ");
                
                System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                System.out.println("digite a altura:");
                altura = leitor.nextDouble();
                System.out.println(" ");
                
                Mulher m1 = new Mulher (nome, dataNascimento, peso, altura);
                vetor[cont] = m1;
                cont++;
                
            } else {
                if (num == 2){
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.println("digite o nome:");
                    nome = leitor.next();
                    System.out.println(" ");
                    
                    for(int e = 0; e < cont; e++){
                        
                    }
                    
                    System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    System.out.println("digite o numero em ordem de cadastro:");
                    int ordem = leitor.nextInt();
                    System.out.println(" ");

                    System.out.println(vetor[ordem].exibirDados());
                    System.out.println(vetor[ordem].resultIMC());
                    System.out.println();
                    
                } else {
                    if (num == 3) {
                        for(int e = 0; e < cont; e++){
                            System.out.println(vetor[e].exibirDados());
                            System.out.println(vetor[e].resultIMC());
                        }
                        
                    } else {
                        if (num > 4) {
                        System.out.println("digitou o numero errado porfavor digite novamente");
                        }
                    } 
                }
            }
        
        }while (num != 4);
        
        System.out.println(vetor[0] );
        
    }
    
}
