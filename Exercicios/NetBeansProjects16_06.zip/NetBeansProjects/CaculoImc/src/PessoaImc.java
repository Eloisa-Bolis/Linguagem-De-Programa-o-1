
import java.awt.BorderLayout;

/**
 *
 * @author 05908897027
 */
abstract class PessoaImc extends Pessoa {
    
    protected double peso;
    protected double altura;
    
    public PessoaImc(String nome, String dataNascimento, double peso, double altura) {
        super(nome, dataNascimento);
        
        this.peso = peso;
        this.altura = altura;
    }
    
    public double getPeso() {
        return peso;
    }
    public double getAltura() {
        return altura;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public double calculaImc(){
        double imc = peso / (altura * altura);
        return imc;
    }    
        
    public String exibirDados() {
    return "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
         + "Nome: " + nome + "\n"
         + "Data de Nascimento: " + dataNascimento + "\n"
         + "Peso: " + peso + "\n"
         + "Altura: " + altura + "\n"
         + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~";
    }
    
    
}
