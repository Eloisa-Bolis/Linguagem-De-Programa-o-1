/**
 *
 * @author 05908897027
 */
public class Mulher extends PessoaImc {
    
    public Mulher(String nome, String dataNascimento, double peso, double altura) {
        super(nome, dataNascimento, peso, altura);
    }
    
    public String resultIMC(){
  
        if (calculaImc() < 19) {
            return "Abaixo do peso";
        } else {
            if (calculaImc() <= 25.8){
                return "Peso ideal";
            } else {
                return "acima do peso";
            }
        }
    }
}
