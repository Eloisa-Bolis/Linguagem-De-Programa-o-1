
import java.util.Arrays;

/**
 *
 * @author 05908897027
 */
public class tabuada {

    private int numero;
    private int[] numerosInteiros;
    
    //c ) Crie o método construtor desta classe que receba como parâmetro o numero. Além de receber e atribui-lo ao
    //atributo numero da classe, este método também deverá criar (instanciar) o vetor de números inteiros declarado
    //na questão a) com 10 posições.
    public tabuada( int numero ){
        this.numero = numero;
        this.numerosInteiros = new int[10];
    }
    
    //d) Crie um método que não receba nenhum parâmetro e que retorne uma string. Se o atributo da classe
    //chamado numero for menor que 4 retorne a string “Tabuada de números pequenos” e se o numero for entre a
    //faixa de 4 até 10 retorne a string “Tabuada de números médios” e se o numero for maior que 10 retorne“Tabuada de números grandes”.
    public int getnumero(){
        return numero;
    }
    public void setnumero(int numero){
        this.numero = numero;
    }
    
    public int[] getnumerosInteiro(int[] numerosInteiros){
        return numerosInteiros;
    }
    public void setnumerosInteiros(int[]numerosInteiros){
        this.numerosInteiros = numerosInteiros;
    }
    
    
    public String retorna(){
        if (this.numero < 4){
            System.out.println("Tabuada de numeros pequenos");
        }
        if (this.numero > 10){
            System.out.println("Tabuada de números grandes");
        } 
        if (4 < this.numero) {
            if( this.numero <= 10){
               System.out.println("Tabuada de números médios"); 
            }
        }
        return null;
    }
   
    //e) Crie um método que não receba nenhum parâmetro e que não retorne nenhum valor. Este método deverá calcular a tabuada 
    //do atributo numero e deverá colocar o resultado do cálculo da tabuada nas 10 posições do atributo vetor de numeros 
    //inteiros da classe (Obs: o cálculo da tabuada e a colocação dos resultados no vetor devem ser feitos usando um comando 
    //de repetição)
    
    public void fazTabuada(){
        for(int i=0; i < 10; i++){
            ///this.numerosInteiros = i * this.numero;
            System.out.println( i + " * " + this.numero + " = " + (i * this.numero));
        }
    }
    
    
    public void exibirDados() {
        tabuada i = new tabuada();
        System.out.println(" ");
        System.out.println("Tabuada do " + this.numero);
        System.out.println( i.fazTabuada);
        System.out.println("----------------------------");
    }
}
