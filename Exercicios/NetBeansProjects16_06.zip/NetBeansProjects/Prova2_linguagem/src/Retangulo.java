/**
 *
 * @author 05908897027
 */
public class Retangulo extends Figura {
    private double lado;
    private double altura;
    
    public Retangulo (double lado, double altura){
        this.lado = lado;
        this.altura = altura;
    }

    public double getLado() {
        return lado;
    }
    public double getAltura() {
        return altura;
    }

    public void setLado(double lado) {
        this.lado = lado;
    }
    public void setAltura(double altura) {
        this.altura = altura;
    }     

    @Override
    double calcularArea() {
        return lado*altura;
    }

    @Override
    double calcularPerimetro() {
        return 2 * (lado + altura);
    }
    
}
