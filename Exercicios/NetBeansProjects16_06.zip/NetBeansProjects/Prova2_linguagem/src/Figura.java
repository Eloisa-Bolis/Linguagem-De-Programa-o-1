/**
 *
 * @author 05908897027
 */
public abstract class Figura {
    abstract double calcularArea();
    abstract double calcularPerimetro();
}
