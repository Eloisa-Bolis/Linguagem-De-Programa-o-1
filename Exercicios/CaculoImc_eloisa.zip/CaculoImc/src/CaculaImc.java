/**
 *
 * @author 05908897027
 */
import java.util.Scanner;
public class CaculaImc {

    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        
        int num;
        double peso;
        double altura;
        String nome;
        String dataNascimento; 
        
        do{
            System.out.println("Escolha o que vc quer calcular");
            System.out.println("Escolha 1: para mulher ");
            System.out.println("Escolha 2: para homem ");
            System.out.println("Escolha 3: para sair ");
            num = leitor.nextInt();
            
            if (num == 1){
                System.out.println("digite seu nome:");
                nome = leitor.next();
                
                System.out.println("digite data de nacimento:");
                dataNascimento = leitor.next();
                
                System.out.println("digite peso:");
                peso = leitor.nextDouble();
                
                System.out.println("digite altura:");
                altura = leitor.nextDouble();
                
                Mulher m1 = new Mulher (nome, dataNascimento, peso, altura);
                m1.calculaImcM();
                
            } else {
                if (num == 2){
                    System.out.println("digite seu nome:");
                nome = leitor.next();
                
                System.out.println("digite data de nacimento:");
                dataNascimento = leitor.next();
                
                System.out.println("digite peso:");
                peso = leitor.nextDouble();
                
                System.out.println("digite altura:");
                altura = leitor.nextDouble();
                
                Homem h1 = new Homem(nome, dataNascimento, peso, altura);
                h1.calculaImcH();
                    
                } else {
                    System.out.println("digitou o numero errado porfavor digite novamente");
                }
            }
        
        }while (num != 3) ;
        
    }
    
}
