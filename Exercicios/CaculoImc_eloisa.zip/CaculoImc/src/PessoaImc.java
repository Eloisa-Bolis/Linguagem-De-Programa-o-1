/**
 *
 * @author 05908897027
 */
abstract class PessoaImc extends Pessoa {
    
    public PessoaImc(String nome, String dataNascimento, double peso, double altura) {
        super(nome, dataNascimento, peso, altura);
    }
    
    public double getPeso() {
        return peso;
    }
    public double getAltura() {
        return altura;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public String toString(){
        return "Nome: " + nome +
               "Data de Nascimento: " + dataNascimento +
               "Peso: " + peso +
               "Altura: " + altura;
        
    }
    
    
}
