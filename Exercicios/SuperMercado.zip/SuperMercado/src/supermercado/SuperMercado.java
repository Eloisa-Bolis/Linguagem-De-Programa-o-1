/*
Instanciar quatro objetos da classe Item. Aplicar
percentuais de desconto para cada um destes objetos.
Obter os valores totais de cada um desses items. E
imprimir na tela um pequeno recibo com a descricao e o
valor total de cada item e no final o valor total do recibo. 
 */
package supermercado;

/**
 *
 * @author 05908897027
 */
public class SuperMercado {

    public static void main(String[] args) {
        
        Item i1 = new Item("001", "chocolate", 10, 0.5, 12.50);
        Item i2 = new Item("001", "chocolate", 10, 0.5, 12.50);
        Item i3 = new Item("001", "chocolate", 10, 0.5, 12.50);
        Item i4 = new Item("001", "chocolate", 10, 0.5, 12.50);
        
        System.out.println("codigo:" + i1.codigo);
        System.out.println("descricao:" + i1.descricao);
        System.out.println("quantidade:" + i1.quantidade);
        System.out.println("desconto:" + i1.desconto);
        System.out.println("preco:" + i1.preco_unitario);
        
    }
    
}
