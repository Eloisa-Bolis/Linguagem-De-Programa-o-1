// sub classe
/**
 *
 * @author 05908897027
 */
public class gerente extends funcionario{
    
    private int senha;
    private int nFunGerenciados;

    public gerente(String nome, String cpf, double salario, int senha, int nFunGerenciados) {
        super(nome, cpf, salario);
        this.senha = senha;
        this.nFunGerenciados = nFunGerenciados;
    }

    public int getSenha() {
        return senha;
    }
    public int getnFunGerenciados() {
        return nFunGerenciados;
    }

    public void setSenha(int senha) {
        this.senha = senha;
    }
    public void setnFunGerenciados(int nFunGerenciados) {
        this.nFunGerenciados = nFunGerenciados;
    }
    
    
    
    public double getBonificacao() {
        return this.salario * 0.15;
    }
    
    public boolean autentica(int senha) {
        if (this.getSenha() == senha) {
            System.out.println("Acesso Permitido!");
            return true;
        } else {
            System.out.println("Acesso Negado!");
            return false;
        }
    }

    public void exibirDadosGe() {
        if (this.autentica(3573)) {
            System.out.println(" Gerente:");
            System.out.println("Nome: " + this.nome);
            System.out.println("Cpf: " + this.cpf );
            System.out.println("Salario: " + this.salario);
            System.out.println("Bonificacao: " + this.getBonificacao());
            System.out.println("Numero de Funcionarios Gerenciados: " + this.nFunGerenciados);
            System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
            
        }
    }
}
