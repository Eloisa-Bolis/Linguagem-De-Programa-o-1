
import java.util.Scanner;

/**
 *
 * @author 05908897027
 */
public class imprimeTabuada {

    public static void main(String[] args) {
        
        Scanner leitor = new Scanner(System.in); 
        
        System.out.println("Digite qual tabuada vc quer saber");
        int numero = leitor.nextInt();
        
        tabuada o1 = new tabuada( numero ); 
        
        o1.retorna();
        o1.exibirDados();
        
       
    }
    
}
