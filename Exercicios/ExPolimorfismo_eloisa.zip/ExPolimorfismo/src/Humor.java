//puper classe
/**
 *
 * @author 05908897027
 */
public class Humor {
    
    //retorna o humor
    protected String getHumor(){    //so a propria classe ou filhas podem chamar
        return "Mal-humorado";
    }
    
    //escreve como o objeto se sente
    public void escreveHumor(){
        System.out.println("eu me sinto " + getHumor());
    }
}
