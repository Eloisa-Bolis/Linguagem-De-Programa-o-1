//super classe
/**
 *
 * @author 05908897027
 */
public abstract class Pessoa {
    
    protected String nome;
    protected String dataNascimento;
    
    public Pessoa (String nome, String dataNascimento){
        this.nome = nome;
        this.dataNascimento = dataNascimento;
        
    }

    public String getNome() {
        return nome;
    }
    public String getDataNascimento() {
        return dataNascimento;
    }
    
    

    public void setNome(String nome) {
        this.nome = nome;
    }
    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    
    public String toString(){
        return " Nome: " + nome +
               " Data de Nascimento: " + dataNascimento;
        
    }
    
    
}
