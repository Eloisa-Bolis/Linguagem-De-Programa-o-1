/**
 *
 * @author 05908897027
 */
public class testeCarro {

    public static void main(String[] args) {
        Carro c1 = new Carro("Fusca");

        System.out.println("Veiculo: ");
        System.out.println("Modelo: " + c1.getModelo());
        c1.mover();
        

        c1.setModelo("Uno");
        System.out.println("Veiculo 2: ");
        System.out.println("Modelo: " + c1.getModelo());
        c1.mover();
    }
}
