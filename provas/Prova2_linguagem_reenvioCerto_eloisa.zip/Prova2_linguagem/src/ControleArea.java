/**
 *
 * @author 05908897027
 */
public class ControleArea {
    private double totalDaArea;
    

    public ControleArea(){
        this.totalDaArea = 0;    
    }
    
    public double getTotalDaArea() {
        return totalDaArea;
    }
    
    public void setTotalDaArea(double totalDaArea) {
        this.totalDaArea = totalDaArea;
    }
    
    public double Registrar(Figura f){
        return this.totalDaArea += f.calcularArea();
    }

}
