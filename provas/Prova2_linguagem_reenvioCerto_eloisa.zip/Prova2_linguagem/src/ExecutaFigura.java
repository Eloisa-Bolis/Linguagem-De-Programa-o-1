/**
 *
 * @author 05908897027
 */
public class ExecutaFigura {

    public static void main(String[] args) {
        
        Retangulo r1 = new Retangulo(8.0, 2.5);
        Retangulo r2 = new Retangulo(13.0, 7.3);
        
        System.out.println("Retangulo 1:");
        System.out.println("Lado: " + r1.getLado());
        System.out.println("Altura: " + r1.getAltura());
        System.out.println("Area: " + r1.calcularArea());
        System.out.println("Perimetro: " + r1.calcularPerimetro());

        System.out.println("\nRetengulo 2:");
        System.out.println("Lado: " + r2.getLado());
        System.out.println("Altura: " + r2.getAltura());
        System.out.println("Area: " + r2.calcularArea());
        System.out.println("Perimetro: " + r2.calcularPerimetro());
        
        ControleArea c1 = new ControleArea( );
        c1.Registrar(r1);
        c1.Registrar(r2);
        
        System.out.println("\nTotal da area dos dois primeiros retangulos: " + c1.getTotalDaArea());
        
        System.out.println("\nCriando 10 retangulos adicionais:");
        for (int i = 0; i < 10; i++) {
            Retangulo r3 = new Retangulo(20, 3);
            r3.setLado(r3.getLado() + i);
            r3.setAltura(r3.getAltura() + i);
            
            ControleArea c2 = new ControleArea( );
            
            c2.Registrar(r3);

            System.out.println("\nRetangulo " + (1 + i) + ":");
            System.out.println("Lado: " + r3.getLado());
            System.out.println("Altura: " + r3.getAltura());
            System.out.println("Area: " + r3.calcularArea());
            System.out.println("Permetro: " + r3.calcularPerimetro());
            System.out.println("\nTotal da area dos 10 retangulos: " + c2.getTotalDaArea());
        }
        
    }
    
}
